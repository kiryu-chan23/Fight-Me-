using System;
using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    public Transform player;          // Reference to the player's position
    public float speed = 3f;          // Speed at which the enemy moves
    public float chaseRange = 5f;     // Distance within which the enemy starts chasing
    public float stopRange = 3f;      // Distance at which the enemy stops to shoot
    public float fireRate = 2f;       // Time between shots

    private Animator animator;        // Reference to the Animator component
    private Rigidbody2D rb;           // Reference to the Rigidbody2D component
    private Vector2 movement;         // Stores movement direction
    private float nextFireTime = 0f;  // Tracks time for the next arrow shot

    public GameObject arrowPrefab;    // Assign the EnemyArrow prefab in the Inspector
    public Transform firePoint;       // Position from where the arrow will be fired

    void Start()
    {
        // Initialize references
        animator = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();

        // Find the player by its PlayerMovement script
        PlayerMovement playerScript = UnityEngine.Object.FindFirstObjectByType<PlayerMovement>();
        if (playerScript != null)
        {
            player = playerScript.transform;
        }
        else
        {
            Debug.LogError("Player object with 'PlayerMovement' script not found!");
        }
    }

    void Update()
    {
        if (player == null) return;

        // Calculate distance to the player
        float distanceToPlayer = Vector2.Distance(transform.position, player.position);

        if (distanceToPlayer <= chaseRange && distanceToPlayer > stopRange)
        {
            // Chase the player
            ChasePlayer();
        }
        else if (distanceToPlayer <= stopRange)
        {
            // Stop moving and attack
            AttackPlayer();
        }
        else
        {
            // Player is out of range; stop movement
            StopEnemy();
        }
    }

    void FixedUpdate()
    {
        // Apply movement
        if (movement != Vector2.zero)
        {
            rb.MovePosition(rb.position + movement * speed * Time.fixedDeltaTime);
        }
    }

    void ChasePlayer()
    {
        // Move towards the player
        Vector2 direction = (player.position - transform.position).normalized;
        movement = direction;

        // Update animations
        animator.SetBool("isWalking", true);
        animator.SetBool("isIdle", false);
        animator.SetBool("isRanged", false);
    }

    void AttackPlayer()
    {
        // Stop movement
        movement = Vector2.zero;

        // Update animations
        animator.SetBool("isWalking", false);
        animator.SetBool("isIdle", false);
        animator.SetBool("isRanged", true);

        // Fire arrows at regular intervals
        if (Time.time >= nextFireTime)
        {
            FireArrow();
            nextFireTime = Time.time + fireRate;
        }
    }

    void StopEnemy()
    {
        // Stop movement
        movement = Vector2.zero;

        // Update animations
        animator.SetBool("isWalking", false);
        animator.SetBool("isIdle", true);
        animator.SetBool("isRanged", false);
    }

    void FireArrow()
    {
        if (arrowPrefab == null || firePoint == null)
        {
            Debug.LogError("Arrow Prefab or Fire Point not assigned!");
            return;
        }

        // Spawn the arrow
        GameObject arrow = Instantiate(arrowPrefab, firePoint.position, firePoint.rotation);

        // Set its movement direction towards the player
        Vector2 direction = (player.position - firePoint.position).normalized;
        arrow.GetComponent<ProjectileBehavior>().SetDirection(direction);
    }

    void OnDrawGizmosSelected()
    {
        // Visualize chase and stop ranges in the editor
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, chaseRange);

        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, stopRange);
    }
}