using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 3f;                // Player's horizontal movement speed
    public float jumpForce = 15f;          // Force applied when jumping
    private Rigidbody2D rb;                // Reference to the Rigidbody2D component
    private Animator animator;             // Reference to the Animator component

    private bool isGrounded = false;       // Tracks if the player is on the ground
    private bool isCrouching = false;      // Tracks if the player is crouching
    private bool isSwording = false;       // Tracks if the player is currently swording

    [Header("Ground Check Settings")]
    public Transform groundCheck;          // Transform for ground check position
    public float groundCheckRadius = 0.2f; // Radius for ground detection
    public LayerMask groundLayer;          // Layer mask to detect ground objects

    [Header("Crouch Settings")]
    public Vector2 normalColliderSize;     // Normal size of the player's collider
    public Vector2 crouchColliderSize;     // Size of the player's collider when crouching
    public Vector2 normalColliderOffset;   // Normal offset of the player's collider
    public Vector2 crouchColliderOffset;   // Offset of the player's collider when crouching
    private BoxCollider2D boxCollider;     // Reference to the player's BoxCollider2D

    // For the HealthCollectible 
    // Add these lines
    public int maxHealth = 5;              // Maximum health
    public int health = 5;                 // Current health

    public void ChangeHealth(int amount)
    {
        health += amount;
        health = Mathf.Clamp(health, 0, maxHealth);
        Debug.Log("Player health: " + health);
    }


    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        boxCollider = GetComponent<BoxCollider2D>();

        // Cache collider size and offset
        if (boxCollider != null)
        {
            normalColliderSize = boxCollider.size;
            normalColliderOffset = boxCollider.offset;

            crouchColliderSize = new Vector2(normalColliderSize.x, normalColliderSize.y / 2);
            crouchColliderOffset = new Vector2(normalColliderOffset.x, normalColliderOffset.y - (normalColliderSize.y / 4));
        }
    }

    void Update()
    {
        float move = Input.GetAxis("Horizontal");

        // Sword Attack
        if (Input.GetMouseButtonDown(1) && !isSwording)
        {
            StartSwordAttack();
        }

        // Crouch
        if (Input.GetKeyDown(KeyCode.S))
        {
            StartCrouch();
        }
        else if (Input.GetKeyUp(KeyCode.S))
        {
            StopCrouch();
        }

        // Movement and Jumping only allowed if not swording
        if (!isSwording)
        {
            if (!isCrouching)
            {
                MovePlayer(move);
            }

            // Jump with W key
            if (Input.GetKeyDown(KeyCode.W) && isGrounded)
            {
                Jump();
            }
        }

        CheckGroundedStatus();
    }

    void MovePlayer(float move)
    {
        rb.linearVelocity = new Vector2(move * speed, rb.linearVelocity.y);

        if (move > 0)
        {
            transform.localScale = new Vector3(1, 1, 1); // Face right
        }
        else if (move < 0)
        {
            transform.localScale = new Vector3(-1, 1, 1); // Face left
        }

        animator.SetBool("isWalking", move != 0);
    }

    void Jump()
    {
        rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
        animator.SetTrigger("Jump");
    }

    void StartCrouch()
    {
        if (isCrouching) return;

        isCrouching = true;
        animator.SetBool("isCrouching", true);

        // Adjust collider for crouching
        if (boxCollider != null)
        {
            boxCollider.size = crouchColliderSize;
            boxCollider.offset = crouchColliderOffset;
        }
    }

    void StopCrouch()
    {
        if (!isCrouching) return;

        isCrouching = false;
        animator.SetBool("isCrouching", false);

        // Reset collider to normal size
        if (boxCollider != null)
        {
            boxCollider.size = normalColliderSize;
            boxCollider.offset = normalColliderOffset;
        }
    }

    void StartSwordAttack()
    {
        isSwording = true;
        animator.SetBool("isSwording", true);

        // Optional: Stop player movement during the attack
        rb.linearVelocity = new Vector2(0, rb.linearVelocity.y);

        // Stop swording after animation duration
        Invoke("StopSwordAttack", 0.5f); // Adjust 0.5f based on animation length
    }

    void StopSwordAttack()
    {
        isSwording = false;
        animator.SetBool("isSwording", false);
    }

    void CheckGroundedStatus()
    {
        Collider2D groundCollider = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);
        isGrounded = groundCollider != null;

        animator.SetBool("isJumping", !isGrounded);
    }

    void OnDrawGizmosSelected()
    {
        if (groundCheck != null)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(groundCheck.position, groundCheckRadius);
        }
    }
}