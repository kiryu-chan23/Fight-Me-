using UnityEngine;

public class EnemyArrow : MonoBehaviour
{
    public float speed = 5f; // Speed of the arrow
    public int damage = 1;   // Damage the arrow deals

    void Update()
    {
        // Move the arrow forward
        transform.Translate(Vector2.right * speed * Time.deltaTime);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        // Check if it hits the player
        if (other.CompareTag("Player"))
        {
            // Apply damage to the player
            PlayerMovement player = other.GetComponent<PlayerMovement>();
            if (player != null)
            {
                player.health -= damage; // Assuming `health` is a public variable
            }
            Destroy(gameObject); // Destroy the arrow after hitting the player
        }
        else if (other.CompareTag("Obstacle"))
        {
            // Destroy the arrow if it hits an obstacle
            Destroy(gameObject);
        }
    }
}