using UnityEngine;

public class ProjectileBehavior : MonoBehaviour
{
    public float speed = 10f; // Arrow speed
    public float lifetime = 5f; // Time before the arrow is destroyed

    private Vector2 direction;

    void Start()
    {
        // Automatically destroy the arrow after its lifetime expires
        Destroy(gameObject, lifetime);
    }

    void Update()
    {
        // Move the arrow forward
        transform.Translate(Vector2.right * speed * Time.deltaTime);
    }

    public void SetDirection(Vector2 dir)
    {
        direction = dir;
        // Flip the arrow if the direction is left
        if (direction.x < 0)
        {
            transform.localScale = new Vector3(-1 * transform.localScale.x, transform.localScale.y, transform.localScale.z);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Check for collisions with the player or other objects
        if (collision.CompareTag("Player"))
        {
            Debug.Log("Arrow hit the player!");
            // Damage the player (implement player health reduction here)
            Destroy(gameObject); // Destroy the arrow
        }
        else if (collision.CompareTag("Environment"))
        {
            // Destroy the arrow if it hits a wall or ground
            Destroy(gameObject);
        }
    }
}