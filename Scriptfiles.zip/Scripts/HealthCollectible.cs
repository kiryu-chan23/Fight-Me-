using UnityEngine;

public class HealthCollectible : MonoBehaviour
{
    public int healthAmount = 1;         // Amount of health restored
    public GameObject collectEffect;    // Optional particle effect

    private void OnTriggerEnter2D(Collider2D other)
    {
        PlayerMovement player = other.GetComponent<PlayerMovement>();

        if (player != null)
        {
            if (player.health < player.maxHealth)
            {
                player.ChangeHealth(healthAmount);
                Debug.Log("Player collected the health collectible!");

                // Optional: Play collection effect
                if (collectEffect != null)
                {
                    Instantiate(collectEffect, transform.position, Quaternion.identity);
                }

                Destroy(gameObject); // Destroy the collectible
            }
        }
    }
}